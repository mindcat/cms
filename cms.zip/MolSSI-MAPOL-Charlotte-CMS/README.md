# MolSSI-MAPOL-Charlotte-CMS
Repository for the 2024 [MolSSI-MAPOL-Charlotte](https://pages.charlotte.edu/molssi-mapol-workshop/) workshop at UNC Charlotte!
![Molecule in a cavity](PCSD0764_ChemTheoryTOC.jpg)
